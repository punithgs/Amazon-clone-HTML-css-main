Amazon clone using
  HTML
  Javascript
  Css
  
